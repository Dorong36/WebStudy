// 조건문 : 단순if문, else if문, if~else문, switch~case문
// 반복문 : for, while, do~while
for(let i = 0; i < 5; i++){
    //실행문
    console.log('😎', i);
}